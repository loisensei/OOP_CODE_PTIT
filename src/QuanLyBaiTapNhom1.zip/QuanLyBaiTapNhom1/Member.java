package QuanLyBaiTapNhom1;

public class Member {
    private String msv,name,phoneNumber;
    private int groupId;
    public Member(String msv, String name, String phoneNumber, int groupId){
        this.msv = msv;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.groupId = groupId;
    }
    public int getGroupId(){
        return this.groupId;
    }
    public String toString(){
        return msv + " " + name + " " + phoneNumber;
    }
}
