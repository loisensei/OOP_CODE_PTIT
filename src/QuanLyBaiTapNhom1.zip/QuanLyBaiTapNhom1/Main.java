package QuanLyBaiTapNhom1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        int n = cin.nextInt();
        int m = cin.nextInt();
        cin.nextLine();
        ArrayList<Member> ds = new ArrayList<>();
        while(n-->0){
            Member a = new Member(cin.nextLine(),cin.nextLine(),cin.nextLine(),Integer.parseInt(cin.nextLine()));
            ds.add(a);
        }
        ArrayList<String> topic = new ArrayList<>();
        while(m-->0){
            topic.add(cin.nextLine());
        }
        int q= Integer.parseInt(cin.nextLine());
        while(q-->0){
            int id = cin.nextInt();
            System.out.println("DANH SACH NHOM "+id+":");
            for(Member i : ds){
                if(i.getGroupId()==id){
                    System.out.println(i);
                }
            }
            System.out.println("Bai tap dang ky: "+topic.get(id-1));

        }

    }
}
